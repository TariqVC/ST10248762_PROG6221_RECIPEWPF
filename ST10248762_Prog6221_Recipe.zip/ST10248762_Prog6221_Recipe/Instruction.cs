﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ST10248762_Prog6221_Recipe
{
    public class Instruction
    {
        public string Step { get; set; }
    }
}
