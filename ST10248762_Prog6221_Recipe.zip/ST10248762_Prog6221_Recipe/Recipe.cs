﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ST10248762_Prog6221_Recipe
{
    public class Recipe // publisher class for the calorie event
    {
        public string Name { get; set; }
        public List<Ingredient> Ingredients { get; set; } = new List<Ingredient>();
        public List<Instruction> Instructions { get; set; } = new List<Instruction>();
        public double TotalCalories { get; private set; }   
        // event message that will be displayed to the user when calorie count goes above 300

        public static event Action<string> CalorieLimitExceeded;
        public Recipe(string name, List<Ingredient> ingredients, List<Instruction> instructions)
        {
            Name = name;
            Ingredients = ingredients;
            Instructions = instructions;
            TotalCalories = ingredients.Sum(i => i.Calories);
        }

        public void Upscale(double factor)
        {
            foreach (var ingredient in Ingredients)
            {
                ingredient.Quantity *= factor;
            }
            TotalCalories = Ingredients.Sum(i => i.Calories);
        }

        public void Downscale(double factor)
        {
            foreach (var ingredient in Ingredients)
            {
                ingredient.Quantity /= factor;
            }
            TotalCalories = Ingredients.Sum(i => i.Calories);
        }
        public void checkCalories()//(IIE, 2024)
        {
            TotalCalories = Ingredients.Sum(i => i.Calories);
            if (TotalCalories > 2000) // Assuming 2000 as a calorie limit for this example
            {
                var foodGroupCausingIssue = Ingredients
                    .GroupBy(i => i.FoodGroup)
                    .OrderByDescending(g => g.Sum(i => i.Calories))
                    .First()
                    .Key;

                string message = $"The recipe exceeds the calorie limit by {TotalCalories - 2000} calories. The food group causing this issue is {foodGroupCausingIssue}.";
                CalorieLimitExceeded?.Invoke(message);
            }//(Wagner B, 2023)
        }
    }
}
