﻿// See https://aka.ms/new-console-template for more information
using ST10248762_Prog6221_Recipe;
using System.Reflection.Metadata.Ecma335;
public class RecipeApp // subcriber class for the events made in the pubblisher class Recipe
{                     // subcriber class is not the same as child class, it is simply a class receving an event
                       //(IIE, 2024)
    
    public static void Main(string[] args)
    {
        RecipeManager manager = new RecipeManager();

        while (true)
        {
            Console.WriteLine("1. Add Recipe");
            Console.WriteLine("2. View Recipe List");
            Console.WriteLine("3. Select Recipe");
            Console.WriteLine("4. Upscale Recipe");
            Console.WriteLine("5. Downscale Recipe");
            Console.WriteLine("6. Delete Recipe");
            Console.WriteLine("7. Exit");
            Console.WriteLine("Enter choice:");
            string choice = Console.ReadLine();

            switch (choice)
            {
                case "1":
                    manager.AddRecipe();
                    break;
                case "2":
                    manager.ViewRecipe();
                    break;
                case "3":
                    manager.SelectRecipe();
                    break;
                case "4":
                    manager.UpscaleRecipe();
                    break;
                case "5":
                    manager.DownscaleRecipe();
                    break;
                case "6":
                    manager.DeleteRecipe();
                    break;
                case "7":
                    Environment.Exit(0);
                    break;
                default:
                    Console.WriteLine("Invalid choice, please enter a number provided for you:");
                    break;
            }
        }
    }
}



