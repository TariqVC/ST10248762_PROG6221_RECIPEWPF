﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ST10248762_Prog6221_Recipe
{
    public class RecipeManager
    {
        public static List<Recipe> recipes = new List<Recipe>();

        public RecipeManager()
        {
            Recipe.CalorieLimitExceeded += message => Console.WriteLine(message);
        }

        /* public void AddRecipe() // method created to add a recipe. It asks the user for the details of the recipe which it is then stored in an array
         {
             Recipe recipe = new Recipe();
             Console.WriteLine("Enter Recipe Name: ");
             recipe.Name = Console.ReadLine();
             int ingredientCount = 0;

             while (true) // used so that if user inputs incorrect variable type the application does not crash
             {
                 try
                 {
                     Console.WriteLine("Enter the number of ingredients:");
                     ingredientCount = int.Parse(Console.ReadLine());
                     if (ingredientCount <= 0)
                     {
                         throw new ArgumentOutOfRangeException("The number of ingredients must be a positive integer.");
                     }
                     break;
                 }
                 catch (Exception ex)
                 {
                     Console.WriteLine($"Invalid input: {ex.Message}. Please enter a valid number."); //(Wagner B, 2023)
                 }
             }

             Console.WriteLine("Enter number of steps for the recipe: ");
             int InstructionCount = int.Parse(Console.ReadLine());

             for (int i = 0; i < ingredientCount; i++)
             {
                 Ingredient ingredient = new Ingredient();
                 Console.WriteLine("Enter ingredient name: ");
                 ingredient.Name = Console.ReadLine();
                 while (true)
                 {
                     try
                     {
                         Console.WriteLine("Enter quantity of ingredient: ");
                         ingredient.Quantity = double.Parse(Console.ReadLine());
                         if (ingredient.Quantity <= 0)
                         {
                             throw new ArgumentOutOfRangeException("The quantity must be a positive number.");
                         }
                         break;
                     }
                     catch (Exception ex)
                     {
                         Console.WriteLine($"Invalid input: {ex.Message}. Please enter a valid number."); //(Wagner B, 2023)
                     }
                 }
                 Console.WriteLine("Enter unit of measurement: ");
                 ingredient.unitOfmeasure = Console.ReadLine();
                 while (true)
                 {
                     try
                     {
                         Console.WriteLine("Enter calories of the ingredient: ");
                         ingredient.Calories = double.Parse(Console.ReadLine());
                         if (ingredient.Calories < 0)
                         {
                             throw new ArgumentOutOfRangeException("The calories must be a non-negative number.");
                         }
                         break;
                     }
                     catch (Exception ex)
                     {
                         Console.WriteLine($"Invalid input: {ex.Message}. Please enter a valid number."); //(Wagner B, 2023)
                     }
                 }
                 Console.WriteLine("Enter which food group the ingredient belongs to: ");
                 ingredient.FoodGroup = SelectFoodGroup();

                 recipe.Ingredients.Add(ingredient);
             }
             for (int j = 0; j < InstructionCount; j++)
             {
                 Instruction instruction = new Instruction();
                 Console.WriteLine($"Enter instruction step {j + 1}: "); //(Wagner B, 2023)
                 instruction.Step = Console.ReadLine();
                 recipe.Instructions.Add(instruction);
             }

             recipe.checkCalories();

             recipes.Add(recipe);
             Console.WriteLine("Recipe added successfully!");
         }*/


        public void AddRecipe()
        {
            Recipe recipe = GetRecipeDetails();
            recipes.Add(recipe);
            Console.WriteLine("Recipe added successfully!");
        }
        private Recipe GetRecipeDetails()
        {
            Console.WriteLine("Enter Recipe Name: ");
            string name = Console.ReadLine();

            List<Ingredient> ingredients = new List<Ingredient>();
            Console.WriteLine("Enter the number of ingredients:");
            int ingredientCount = int.Parse(Console.ReadLine());

            for (int i = 0; i < ingredientCount; i++)
            {
                Ingredient ingredient = new Ingredient();
                Console.WriteLine("Enter ingredient name: ");
                ingredient.Name = Console.ReadLine();
                Console.WriteLine("Enter quantity of ingredient: ");
                ingredient.Quantity = double.Parse(Console.ReadLine());
                Console.WriteLine("Enter unit of measurement: ");
                ingredient.unitOfmeasure = Console.ReadLine();
                Console.WriteLine("Enter calories of the ingredient: ");
                ingredient.Calories = double.Parse(Console.ReadLine());
                Console.WriteLine("Enter which food group the ingredient belongs to: ");
                ingredient.FoodGroup = (FoodGroup)Enum.Parse(typeof(FoodGroup), Console.ReadLine(), true);

                ingredients.Add(ingredient);
            }

            List<Instruction> instructions = new List<Instruction>();
            Console.WriteLine("Enter number of steps for the recipe: ");
            int instructionCount = int.Parse(Console.ReadLine());

            for (int i = 0; i < instructionCount; i++)
            {
                Instruction instruction = new Instruction();
                Console.WriteLine($"Enter instruction step {i + 1}: ");
                instruction.Step = Console.ReadLine();
                instructions.Add(instruction);
            }

            return new Recipe(name, ingredients, instructions);
        }


        public FoodGroup SelectFoodGroup() // enum (IIE, 2024)
        {
            Console.WriteLine("Select food group:");
            foreach (var foodGroup in Enum.GetValues(typeof(FoodGroup)))
            {
                Console.WriteLine($"{(int)foodGroup}. {foodGroup}");
            }
            int foodGroupChoice = int.Parse(Console.ReadLine());
            return (FoodGroup)foodGroupChoice;
        }

        public void ViewRecipe() //method used to show a format of the recipe for the user to view
        {
            if (recipes.Count == 0)
            {
                Console.WriteLine("Recipe not found. Enter Recipe to view it");

            }
            else
            {
                var sortedRecipes = recipes.OrderBy(r => r.Name).ToList(); // (How to Sort a List by a Property in the Object, 2023)
                Console.WriteLine("Recipes:");
                for (int i = 0; i < sortedRecipes.Count; i++)
                {
                    Console.WriteLine($"{i + 1}. {sortedRecipes[i].Name}"); //(Wagner B, 2023)
                }
            }

        }

        public void SelectRecipe() // shows the user the list of recipe names for them to choose. by doing so it will provide them with the details of the recipe
        {
            ViewRecipe();
            Console.WriteLine("Enter the number of the recipe you wish to view: ");
            int index = int.Parse(Console.ReadLine()) - 1;

            if (index >= 0 && index < recipes.Count)
            {
                Recipe recipe = recipes[index];
                Console.WriteLine($"Recipe Name: {recipe.Name}");
                Console.WriteLine("Ingredients:");
                foreach (var ingredient in recipe.Ingredients)
                {
                    Console.WriteLine($"{ingredient.Quantity} {ingredient.unitOfmeasure} of {ingredient.Name}. ({ingredient.Calories} calories) - Food Group: {ingredient.FoodGroup}");
                }
                Console.WriteLine($"Total Calories: {recipe.TotalCalories}");
                Console.WriteLine("Instructions:");
                for (int i = 0; i < recipe.Instructions.Count; i++)
                {
                    Console.WriteLine($"Step {i + 1}: {recipe.Instructions[i].Step}"); //(Wagner B, 2023)
                }

            }
            else
            {
                Console.WriteLine("Invalid recipe number, please select another number.");
            }
        }

        /* public void UpscaleRecipe() //method used to upscale the ingredient quantity according to the user value
         {
             ViewRecipe(); // so that the user can choose which recipe to upscale/downscale
             Console.WriteLine("Enter the number of the recipe to upscale:");
             int index = int.Parse(Console.ReadLine()) - 1;

             if (index >= 0 && index < recipes.Count)
             {
                 Recipe recipe = recipes[index];
                 Console.WriteLine("Enter how much you wish to increase the quantity of the ingredients: ");
                 double userUpscale = double.Parse(Console.ReadLine());

                 foreach (var ingredient in recipe.Ingredients)
                 {
                     ingredient.Quantity *= userUpscale;
                     ingredient.Calories *= userUpscale;
                 }
                 recipe.checkCalories();
                 Console.WriteLine("Recipe upscaled successfully!");
             }
             else
             {
                 Console.WriteLine("Invalid recipe number, please select another number");
             }
         }*/
        public void UpscaleRecipe()
        {
            ViewRecipe();
            Console.WriteLine("Enter the number of the recipe to upscale:");
            int index = int.Parse(Console.ReadLine()) - 1;

            if (index >= 0 && index < recipes.Count)
            {
                Console.WriteLine("Enter how much you wish to increase the quantity of the ingredients: ");
                double factor = double.Parse(Console.ReadLine());
                recipes[index].Upscale(factor);
                Console.WriteLine("Recipe upscaled successfully!");
            }
            else
            {
                Console.WriteLine("Invalid recipe number, please select another number.");
            }
        }


        /* public void DownscaleRecipe() // method used to downscale the ingredient quantity according to the user value. also used to reset it
         {
             ViewRecipe();
             Console.WriteLine("Enter the number of the recipe to downscale:");
             int index = int.Parse(Console.ReadLine()) - 1;

             if (index >= 0 && index < recipes.Count)
             {
                 Recipe recipe = recipes[index];
                 Console.WriteLine("Enter how much you wish to decrease the quantity of the ingredients: ");
                 double userDownscale = double.Parse(Console.ReadLine());

                 foreach (var ingredient in recipe.Ingredients)
                 {
                     ingredient.Quantity /= userDownscale;
                     ingredient.Calories /= userDownscale;
                 }
                 recipe.checkCalories();
                 Console.WriteLine("Recipe downscaled successfully!");
             }
             else
             {
                 Console.WriteLine("Invalid recipe number, please select another number");
             }

         }*/
        public void DownscaleRecipe()
        {
            ViewRecipe();
            Console.WriteLine("Enter the number of the recipe to downscale:");
            int index = int.Parse(Console.ReadLine()) - 1;

            if (index >= 0 && index < recipes.Count)
            {
                Console.WriteLine("Enter how much you wish to decrease the quantity of the ingredients: ");
                double factor = double.Parse(Console.ReadLine());
                recipes[index].Downscale(factor);
                Console.WriteLine("Recipe downscaled successfully!");
            }
            else
            {
                Console.WriteLine("Invalid recipe number, please select another number.");
            }
        }

        public void DeleteRecipe() //method created to delete the recipe
        {
            ViewRecipe();
            Console.WriteLine("Enter the number of the recipe to delete:");
            int index = int.Parse(Console.ReadLine()) - 1;

            if (index >= 0 && index < recipes.Count)
            {
                recipes.RemoveAt(index);
                Console.WriteLine("Recipe deleted successfully!");
            }
            else
            {
                Console.WriteLine("Invalid recipe number.");
            }
        }
        public void FilterRecipes()
        {
            Console.WriteLine("Enter the name of an ingredient to filter by:");
            string ingredientName = Console.ReadLine();
            Console.WriteLine("Enter the food group to filter by (leave blank if not applicable):");
            string foodGroupInput = Console.ReadLine();
            FoodGroup? foodGroup = null;
            if (!string.IsNullOrEmpty(foodGroupInput))
            {
                foodGroup = (FoodGroup)Enum.Parse(typeof(FoodGroup), foodGroupInput, true);
            }
            Console.WriteLine("Enter the maximum number of calories (leave blank if not applicable):");
            string maxCaloriesInput = Console.ReadLine();
            double? maxCalories = null;
            if (double.TryParse(maxCaloriesInput, out double maxCal))
            {
                maxCalories = maxCal;
            }

            var filteredRecipes = recipes.AsEnumerable();

            if (!string.IsNullOrEmpty(ingredientName))
            {
                filteredRecipes = filteredRecipes.Where(r => r.Ingredients.Any(i => i.Name.Equals(ingredientName, StringComparison.OrdinalIgnoreCase)));
            }

            if (foodGroup.HasValue)
            {
                filteredRecipes = filteredRecipes.Where(r => r.Ingredients.Any(i => i.FoodGroup == foodGroup.Value));
            }

            if (maxCalories.HasValue)
            {
                filteredRecipes = filteredRecipes.Where(r => r.TotalCalories <= maxCalories.Value);
            }

            Console.WriteLine("Filtered Recipes:");
            foreach (var recipe in filteredRecipes)
            {
                Console.WriteLine(recipe.Name);
            }
        }
    }

}
