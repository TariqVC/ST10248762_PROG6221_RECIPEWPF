﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ST10248762_Prog6221_Recipe
{
    public enum FoodGroup // (IIE, 2024)
    {
        starchyFoods,
        vegetablesAndfruits,
        DryBeansPeasLentilsAndSoya,
        ChickenFishMeatAndEggs,
        MilkAndDairyProducts,
        FatsAndOil,
        Water
    }
    public class Ingredient
    {
        public String Name { get; set; }
        public Double Quantity { get; set; }
        public String unitOfmeasure { get; set; }
        public double Calories { get; set; }
        public FoodGroup FoodGroup { get; set; }
    }

}
