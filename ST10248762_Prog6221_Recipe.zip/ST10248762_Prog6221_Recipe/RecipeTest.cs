﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.Collections.Generic;

namespace ST10248762_Prog6221_Recipe
{
    internal class RecipeTest // unit testing 
    {
        [TestMethod]
    public void TestTotalCalories()
        {
            // Arrange
            var ingredients = new List<Ingredient>
        {
            new Ingredient { Name = "Sugar", Quantity = 100, unitOfmeasure = "grams", Calories = 387, FoodGroup = FoodGroup.starchyFoods},
            new Ingredient { Name = "Butter", Quantity = 50, unitOfmeasure = "grams", Calories = 360, FoodGroup = FoodGroup.FatsAndOil }
        };

            var recipe = new Recipe { Name = "Cake", Ingredients = ingredients };

            // Act
            double totalCalories = recipe.TotalCalories;

            // Assert
            Assert.AreEqual(747, totalCalories);
        }
    }
}
